library(tidyverse)
library(dplyr)
library(caret)     # Per la suddivisione dei dati e la valutazione delle prestazioni
library(e1071)     # Per il modello di Naive Bayes
library(rpart)     # Per il modello di Decision Tree
library(maptree)   # Per la visualizzazione degli alberi decisionali
library(ggplot2)   # Per la visualizzazione dei risultati
library(knitr)

Obesity <- read_csv("C:/Users/Utente/Desktop/R_project/Obesity.csv")

##rinomo i levels 
Obesity$Gender <-factor(ifelse(Obesity$Gender == "Male", "Maschio", "Femmina")) 
Obesity$family_history_with_overweight <-factor(ifelse(Obesity$family_history_with_overweight == "yes", "Si", "No")) 
Obesity$FAVC <-factor(ifelse(Obesity$FAVC == "yes", "Si", "No")) 
Obesity$SMOKE <-factor(ifelse(Obesity$SMOKE == "yes", "Si", "No")) 
Obesity$SCC <-factor(ifelse(Obesity$SCC == "yes", "Si", "No")) 
Obesity$CAEC <-factor(Obesity$CAEC)
Obesity$CALC <-factor(Obesity$CALC)
Obesity$NObeyesdad <-factor(Obesity$NObeyesdad)
Obesity$MTRANS <-factor(Obesity$MTRANS)

##riordino i levles 
Obesity$CALC <- factor(Obesity$CALC, levels = c( "Always","Frequently", "no" , "Sometimes"))
Obesity$MTRANS <- factor(Obesity$MTRANS, levels = c("Bike",  "Motorbike" , "Walking", "Automobile", "Public_Transportation" ))
Obesity$NObeyesdad <- factor(Obesity$NObeyesdad, levels = c("Insufficient_Weight", "Normal_Weight", "Overweight_Level_I",  "Overweight_Level_II",   "Obesity_Type_I",      "Obesity_Type_II", "Obesity_Type_III" ))
Obesity$CAEC <- factor(Obesity$CAEC, levels = c("no", "Sometimes", "Frequently", "Always"))


#rinomo i levels 
levels(Obesity$CAEC) <- c("Sempre", "Frequentemente", "No", "Qualche volta")
levels(Obesity$SMOKE) <- c("Sempre","Frequentemente","No","Qualche volta")
levels(Obesity$MTRANS)<- c( "Bici", "Motociclo", "A piedi", "Machina","Trasporto pubblico")
levels(Obesity$NObeyesdad)<- c( "Sotto_Peso", "Normo_Peso", "SovrappesoL1", "SovrappesoL2","ObesitàT1","ObesitàT2","ObesitàT3" )

# Rimozione delle variabili non influenti
obesity_data1 <- subset(Obesity, select = -c(Gender, Age, CALC , SMOKE, SCC, Height))

# Suddivisione del dataset in training e test set
set.seed(25)  
trainIndex <- createDataPartition(obesity_data1$NObeyesdad, p = 0.7, list = FALSE)
train_data <- obesity_data1[trainIndex, ]
test_data <- obesity_data1[-trainIndex, ]


# Addestramento del modello di Decision Tree
decision_tree_model <- rpart(NObeyesdad ~ ., data = train_data, method = "class")
# Predizione sul dataset di test
pred_dt <- predict(decision_tree_model, test_data, type = "class")

# Valutazione delle prestazioni e Visualizzazione delle metriche
conf_matrix_dt <- confusionMatrix(pred_dt, test_data$NObeyesdad)
metrics_dt <- data.frame(
  Precision = conf_matrix_dt$byClass[,"Precision"],
  Recall = conf_matrix_dt$byClass[,"Recall"],
  F1_Score = conf_matrix_dt$byClass[,"F1"],
  Support = rowSums(conf_matrix_dt$table)  
)

confusion_matrix_dt <- kable(metrics_dt, caption = "Metriche di Performance del modello  di Decision Tree  per Classe")

# Addestramento del modello di Naive Bayes
naive_bayes_model <- naiveBayes(NObeyesdad ~ ., data = train_data)

# Predizione sul dataset di test
pred_nb <- predict(naive_bayes_model, test_data)

# Valutazione delle prestazioni e Visualizzazione delle metriche
conf_matrix_nb <- confusionMatrix(pred_nb, test_data$NObeyesdad)
# Convertire le metriche per classe in un data frame
metrics <- data.frame(
  Precision = conf_matrix_nb$byClass[,"Precision"],
  Recall = conf_matrix_nb$byClass[,"Recall"],
  F1_Score = conf_matrix_nb$byClass[,"F1"],
  Support = rowSums(conf_matrix_nb$table)  
)

confusion_matrix_nb <- kable(metrics, caption = "Metriche di Performance del modello di Naive Bayes modello  per Classe")


# Visualizzazione dell'importanza delle variabili nel modello di Decision Tree
importance_dt <- varImp(decision_tree_model)
variable <- c("Consumo_Cibo_tra_pasti", "Consumo_giornaliero_acqua", "Frequenza_Attività_Fisica", "Storia_Famigliare_Con_SovraPeso", "Frequenze_Consumo_Verdure", "Consumo_Alimenti_Alto_Calori", "Trasporto_Utilizzato", "Numero_pasti_principale"
, "Tempo_Utulizzo_dispositivi_Tecnologici", "Peso")

importance_dt$importace <-variable

#grafico
ggplot(importance_dt, aes(x = reorder(importace,Overall), y = Overall,fill =importace )) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(title = "Importanza delle variabili nel modello di Decision Tree",
       x = "Variabile",
       y = "Importanza")+
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5))