library(tidyverse)
library(dplyr)
library(ggplot2)
library(data.table)
library(ggjoy)
library(cowplot)
library(gridExtra)
library(grid)


Obesity <- read_csv("C:/Users/Utente/Desktop/R_project/Obesity.csv")
## Rinomo delle colonne
 setnames(Obesity, old = "Gender", new = "Genere")
 setnames(Obesity, old = "Age", new = "Età")
 setnames(Obesity, old = "Height", new = "Altezza")
 setnames(Obesity, old = "Weight", new = "Peso")
 setnames(Obesity, old = "family_history_with_overweight", new = "Storia_Famigliare_Con_SovraPeso")
 setnames(Obesity, old = "FAVC", new = "Consumo_Alimenti_Alto_Calori")
 setnames(Obesity, old = "FCVC", new = "Frequenze_Consumo_Verdure")
 setnames(Obesity, old = "NCP", new = "Numero_pasti_principale")
 setnames(Obesity, old = "CAEC", new = "Consumo_Cibo_tra_pasti")
 setnames(Obesity, old = "SMOKE", new = "Fumatore")
 setnames(Obesity, old = "CH2O", new = "Consumo_giornaliero_acqua")
 setnames(Obesity, old = "SCC", new = "Monitario_Consumo_Calorie")
 setnames(Obesity, old = "FAF", new = "Frequenza_Attività_Fisica")
 setnames(Obesity, old = "TUE", new = "Tempo_Utulizzo_dispositivi_Tecnologici")
 setnames(Obesity, old = "CALC", new = "Consumo_Alcool")
 setnames(Obesity, old = "MTRANS", new = "Trasporto_Utilizzato")
 setnames(Obesity, old = "NObeyesdad", new = "Categorie_Peso")
 
##rinomo i levels 
Obesity$Genere <-factor(ifelse(Obesity$Genere == "Male", "Maschio", "Femmina")) 
Obesity$Storia_Famigliare_Con_SovraPeso <-factor(ifelse(Obesity$Storia_Famigliare_Con_SovraPeso == "yes", "Si", "No")) 
Obesity$Consumo_Alimenti_Alto_Calori <-factor(ifelse(Obesity$Consumo_Alimenti_Alto_Calori == "yes", "Si", "No")) 
Obesity$Fumatore <-factor(ifelse(Obesity$Fumatore == "yes", "Si", "No")) 
Obesity$Monitario_Consumo_Calorie <-factor(ifelse(Obesity$Monitario_Consumo_Calorie == "yes", "Si", "No")) 
Obesity$Consumo_Cibo_tra_pasti <- factor(Obesity$Consumo_Cibo_tra_pasti)
Obesity$Consumo_Alcool <- factor(Obesity$Consumo_Alcool)
Obesity$Categorie_Peso <- factor(Obesity$Categorie_Peso)
Obesity$Trasporto_Utilizzato <- factor(Obesity$Trasporto_Utilizzato)

##riordino i levles 
Obesity$Consumo_Alcool <- factor(Obesity$Consumo_Alcool, levels = c( "Always","Frequently", "no" , "Sometimes"))
Obesity$Trasporto_Utilizzato <- factor(Obesity$Trasporto_Utilizzato, levels = c("Bike", "Motorbike", "Walking", "Automobile", "Public_Transportation" ))
Obesity$Categorie_Peso <- factor(Obesity$Categorie_Peso, levels = c("Insufficient_Weight", "Normal_Weight", "Overweight_Level_I",  "Overweight_Level_II",   "Obesity_Type_I",      "Obesity_Type_II", "Obesity_Type_III" ))
Obesity$Consumo_Cibo_tra_pasti <- factor(Obesity$Consumo_Cibo_tra_pasti, levels = c("no", "Sometimes", "Frequently", "Always"))

#rinomo i levels 
levels(Obesity$Consumo_Cibo_tra_pasti) <- c("Sempre", "Frequentemente", "No", "Qualche volta")
levels(Obesity$Consumo_Alcool) <- c("Sempre","Frequentemente","No","Qualche volta")
levels(Obesity$Trasporto_Utilizzato)<- c( "Bici", "Motociclo", "A piedi", "Machina","Trasporto pubblico")
levels(Obesity$Categorie_Peso)<- c( "Sotto_Peso", "Normo_Peso", "Sovrappeso_di_levello_I", "Sovrappeso_di_levello_II","Obesità_di_tipo_I","Obesità_di_tipo_II","Obesità_di_tipo_III" )

#calcoliamo l'indice  di massa corporea (BMI) 
Obesity$Indice_massa_Corporea <- Obesity$Peso / Obesity$Altezza^2

## VISUALIZZAZIONE DEI DATI
#Creiamo una funzione showplot per la visualizzazione dei dati
showplot <- function(Obesity, columnname) {
  # Calcolo i conteggi dei valori
  value_counts <- Obesity %>% count(!!sym(columnname)) %>% arrange(desc(n))
  labels <- value_counts[[1]]
  counts <- value_counts[[2]]
  colors <- c("#4caba4", "#d68c78", '#a3a2a2', '#ab90a0', '#e6daa3', '#6782a8', '#8ea677')
  
  # Grafico a ciambel
  donut_data <- data.frame(
    label = labels,
    count = counts,
    fraction = counts / sum(counts)
  )
  
  donut_plot <- ggplot(donut_data, aes(x = 2, y = fraction, fill = label)) +
    geom_bar(stat = "identity", color = "white", width = 0.5) +
    coord_polar(theta = "y", start = 0) +
    xlim(0.5, 2.5) +
    theme_void() +
    theme(legend.position = "right") +
    geom_text(aes(label = scales::percent(fraction, accuracy = 1)), 
              position = position_stack(vjust = 0.5), color = "white", size = 3) +
    scale_fill_manual(values = colors)
  
  # Grafico a barre
  count_plot <- ggplot(Obesity, aes_string(y = columnname, fill = columnname)) +
    geom_bar() +
    geom_text(stat = 'count', aes(label = ..count..), hjust = 1, size = 3) +
    scale_fill_manual(values = colors) +
    theme_minimal() +
    theme(axis.title.x = element_blank(),
          axis.text.x = element_blank(),
          axis.ticks.x = element_blank(),
          legend.position = "none",
          plot.margin = unit(c(1, 1, 1, 5), "cm")) # Espande i margini a sinistra
  
  # Combino i grafici
  combined_plot <- plot_grid(donut_plot, count_plot, nrow = 1, rel_widths = c(1, 1.5))
  title <- ggdraw() + draw_label(columnname, fontface = 'bold', size = 20)
  plot_grid(title, combined_plot, ncol = 1, rel_heights = c(0.1, 1))
}




###1_fattori di rischio 
## principali fattori di rischio associati all'obesità

##verifichiamo le distribuzione del categorie di peso nel dataset
showplot(Obesity, 'Categorie_Peso')
  #dal grafico vediamo che 
  # 13% peso insuffisciente 
  # 14% peso normale 
  # 14% Sovrapeso di livello I
  # 14% Sovrapeso di livello II
  # 17% obesità di tipo I
  # 14% obesità di tipo II
  # 14% obesità di tipo III


## RAPPORTO GENETICA ELL'OBESITA
showplot(Obesity, 'Storia_Famigliare_Con_SovraPeso')
  #si osserva 82% di persoone con storia famigliare con sovrapeso che è maggiore 
  #a 18% di personne che non hanno una storia famigliare con sovrapeso 

##verifichiamo il rischio di obesità per questi due categorie  
Obesity_proporzione_2 <- Obesity %>%
  group_by(Categorie_Peso,Storia_Famigliare_Con_SovraPeso) 
ggplot(Obesity_proporzione_2, aes(x = ..count.., y = Categorie_Peso, fill = Storia_Famigliare_Con_SovraPeso)) +
  geom_bar(position = "dodge") +
  scale_fill_manual(values = c("#4caba4", "#d68c78" ))+
  labs(
    title = "Storia famigliare con Sovrapeso per Categorie di Peso ",
    x = "Count",
    y = "Categorie di Peso",
    fill = "Storia Famigliare Con SovraPeso"
  ) +
  theme_minimal() +
  theme(
    legend.position = "right",
    plot.title = element_text(hjust = 0.5)
  )
  #Dal grafico si osserva che le proporzioni di obesità sono elevate tra le persone con una storia 
  #familiare di sovrappeso. Quindi, la storia familiare di sovrappeso si presenta come un potenziale fattore di rischio per l'obesità. 
  #Tuttavia, questo può essere dovuto a l'età delle persone.


#Controlliamo l'andamento nell'età della categoria Storia_Familiare_Con_Sovrappeso.
ggplot(Obesity, aes(x = Età, fill = Storia_Famigliare_Con_SovraPeso)) +
  geom_density(alpha = 0.5) +
  labs(x = "Età", y = "Density", fill = "Storia Famigliare Con SovraPeso") +
  theme_minimal()
  #I giovani con età < 25 hanno una densità elevata di persone senza una storia familiare di sovrappeso, 
  #mentre l'intervallo di età [20-30] sembra mostrare un picco di densità di persone con una storia familiare di sovrappeso elevata.

#Visualizziamo la distribuzione delle categorie di peso per intervalli di età. 
Obesity <- Obesity %>%
  mutate(Gruppo_Età= case_when(
    Età > 10 & Età <= 20  ~ "10-20",
    Età > 20 & Età <= 30  ~ "20-30",
    Età > 30 & Età <= 40  ~ "30-40",
    Età> 40 & Età <= 50  ~ "40-50",
    Età> 50 & Età<= 60  ~ "50-60",
    Età > 60            ~ "più di60"
  ))

#grafico 
cross_tab <- table(Obesity$Categorie_Peso, Obesity$Gruppo_Età)
 ggplot(data = as.data.frame.table(cross_tab), aes(Var2, Var1, fill = Freq)) +
  geom_tile(color = "white") +
  scale_fill_gradient(low = "#F2F3F4", high = "#4c77af") +  # Personalizza i colori del gradiente
  geom_text(aes(label = Freq), color = "black", size = 4) +
  labs(title = "Categorie di peso per intervalli di Et", x = "", y = "") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))



  #L'intervallo di età 20-30 presenta una proporzione molto elevata di persone con obesità.
  #Quindi, la storia familiare di sovrappeso influenza di più sull'obesità.
 
#RAPPORTO TRA CONSUMO DI ALIMENTI AD ALTO CONTENUTO CALORICO E L'OBESITÀ
showplot(Obesity, 'Consumo_Alimenti_Alto_Calori')
  #Dal grafico si vede che l'88% delle persone che hanno un consumo frequente di alimenti ad alto contenuto calorico

#Osserviamo tra queste due categorie quale rappresenta un rischio maggiore di obesità.
# Grafico
Obesity_proporzione_5 <- Obesity %>%
  group_by(Categorie_Peso,Consumo_Alimenti_Alto_Calori) 
ggplot(Obesity_proporzione_5, aes(x = ..count.., y = Categorie_Peso, fill = Consumo_Alimenti_Alto_Calori)) +
  geom_bar(position = "dodge") +
  scale_fill_manual(values = c("#4caba4", "#d68c78" ))+
  labs(
    title = "Consumo frequente di Alimenti Ad alto calori",
    x = "Count",
    y = "Consumo_Alimenti_Alto_Calori",
    fill = "Consumo_Alimenti_Alto_Calori"
  ) +
  theme_minimal() +
  theme(
    legend.position = "right",
    plot.title = element_text(hjust = 0.5)
  )

  #Osserviamo che le proporzioni sono molto elevate tra le persone con obesità, soprattutto tra quelle con obesità grave.
  #l'88% delle persone  hanno un consumo frequente di alimenti ad alto contenuto calorico.
  #presenta un'elevata proporzione di obesità rispetto a quelle che non hanno un consumo frequente di alimenti ad alto contenuto calorico.
  #Quindi, il consumo frequente di alimenti ad alto contenuto calorico si presenta come un fattore di rischio per l'obesità.

##Valutiamo l'associazione tra categorie di sesso
Obesity_proporzione_6 <- Obesity %>%
  group_by(Genere,Consumo_Alimenti_Alto_Calori)%>%
  summarise(Count = n())
# visualizazione
ggplot(Obesity_proporzione_6, aes(x = Genere, y = Count, fill = Consumo_Alimenti_Alto_Calori)) +
  geom_bar(position = "dodge", stat = "identity") +
  geom_text(aes(label = Count), position = position_dodge(width = 0.9), vjust = -0.5) +
  scale_fill_manual(values = c("#4caba4", "#d68c78" ))+
  labs(
    title = "Consumo di alimenti ad alto calori per Genere",
    x = "Genere",
    y = "Count",
    fill = "Consumo di Alimenti Alto Calori"
  ) +
  theme_minimal() +
  theme(
    legend.position = "right",
    plot.title = element_text(hjust = 0.5)
  )

  #Dal grafico si vede che ci sono più maschi che consumano frequentemente alimenti ad alto contenuto calorico rispetto alle femmine. 
  #Tuttavia, entrambi i sessi presentano un alto consumo frequente di alimenti ad alto contenuto calorico.


#verifichiamo la distribuzione  delle categorie di peso  per questi due gategorie di genere  
Obesity_proporzione_7 <- Obesity %>%
  group_by(Categorie_Peso, Genere) %>%
  summarise(
    count = n(),
    mean_IBM = mean(Indice_massa_Corporea)
  ) %>%
  ungroup()

# grafico
ggplot(Obesity_proporzione_7, aes(x = mean_IBM, y = Categorie_Peso, color = Genere, shape = Genere, size = count)) +
  geom_point() +
  scale_color_manual(values = c("Femmina" = "red", "Maschio" = "blue")) +
  scale_shape_manual(values = c("Femmina" = 19, "Maschio" = 19)) + 
  labs(x = "Indice di massa corporea (IBM)", y = "Categorie di peso", color = "Genere", shape = "Genere", size = "Count") +
  theme_minimal() +
  theme(
    legend.position = "right",
    axis.text.y = element_text(size = 12),
    axis.title.y = element_text(size = 14, face = "bold"),
    axis.title.x = element_text(size = 14, face = "bold")
  )

  #dal grafico si osserva più femmine con obesità grave e più maschi con obesità di tipo II

#RAPPORTO TRA FREQUENZA DI ATIVITA FISICA ELL'OBESITA 
mean_age_by_category <-Obesity %>%
  group_by(Categorie_Peso) %>%
  summarise(Mean_FAF = mean(Frequenza_Attività_Fisica, na.rm = TRUE)) %>%
  arrange(desc(Mean_FAF))
# grafico
ggplot(mean_age_by_category, aes(x = Mean_FAF, y = reorder(Categorie_Peso, Mean_FAF), fill = Mean_FAF)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = round(Mean_FAF, 2)), hjust = 3, size = 5) +
  scale_fill_gradient(low = "#F2F3F4", high = "lightblue") +
  labs(title = "Attività fisica media per categorie di Peso", x = "Frequenza di attività fisica", y = "", fill = "Frequenza_Attività_Fisica Media") +
  theme_minimal()
  #La maggior parte di coloro che hanno un'obesità grave presenta un livello di FAF molto basso,
  #mentre coloro con un peso normale e sottopeso hanno un livello di FAF molto alto. 
  #Quindi, la mancanza di attività fisica può essere associata al rischio di obesità.


##2 Stili di vità Associato a l'obesità
#creiamo una funzione plot_distribution per la visualizazione dei dati 
plot_distribution <- function(Obesity, target_column) {
  # Controllo se la colonna esiste nel mio  dataframe
  if (!target_column %in% colnames(Obesity)) {
    stop(paste("Colonna", target_column, "non trovata nel dataset"))
  }
  
  # Calcolo i value counts
  value_counts <- as.data.frame(table(Obesity[[target_column]]))
  colnames(value_counts) <- c(target_column, "Count")
  colors <- c("#4caba4", "#d68c78", '#a3a2a2', '#ab90a0', '#e6daa3', '#6782a8', '#8ea677')
  
  #grafico a barre 
  bar_plot <- ggplot(value_counts, aes_string(x = target_column, y = "Count", fill = target_column)) +
    geom_bar(stat = "identity") +
    geom_text(aes(label = Count), vjust = -0.5) +
    scale_fill_manual(values = colors)+
    labs(x = target_column, y = "Count") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  
  # grafico a torta
  value_counts$Percentage <- round(value_counts$Count / sum(value_counts$Count) * 100, 1)
  pie_plot <- ggplot(value_counts, aes(x = "", y = Count, fill = as.factor(get(target_column)))) +
    geom_bar(stat = "identity", width = 1) +
    coord_polar("y") +
    geom_text(aes(label = paste0(Percentage, "%")), position = position_stack(vjust = 0.5)) +
    scale_fill_manual(values = colors)+
    labs(fill = target_column) +
    theme_minimal() +
    theme(axis.title.x = element_blank(),
          axis.title.y = element_blank(),
          axis.text = element_blank(),
          axis.ticks = element_blank())
  
  # Combino i grafici
  combined_plot <- plot_grid(bar_plot, pie_plot, nrow = 1, rel_widths = c(1, 1.5))
  title <- ggdraw() + draw_label(target_column, fontface = 'bold', size = 20)
  plot_grid(title, combined_plot, ncol = 1, rel_heights = c(0.1, 1))
}



#RAPPORTO IL FUMO E L'OBESITA
 plot_distribution(Obesity, "Fumatore")
  # dal grafico si vede che la maggiore parte non fumano 

#visualizziamo la distribuzione delle categorie di peso per queste due categorie 
 Obesity %>%
  group_by(Categorie_Peso, Fumatore) %>%
ggplot(aes(x=Indice_massa_Corporea, y=Categorie_Peso, fill= Fumatore))+
  geom_joy(scale=2)+
  scale_y_discrete(expand = c(0.01, 0))+
  scale_x_continuous(expand = c(0.01, 0))+
  theme_joy()+ 
  scale_fill_manual(values = c("grey","orange"))+
  labs(title = "Andamento del percentuale di fumatore per categorie di peso",
       x = "Indice di massa corperea",
       y = "Categorie di Peso")+
  theme(plot.title = element_text(hjust = 0.5))
 
  #Dal grafico osserviamo che tutti coloro con obesità grave non fumano. 
  #Tuttavia, si osservano più fumatori tra coloro con obesità di livello I, II e sovrappeso.
  #Sembra quindi che il fatto di fumare non sia associato a un rischio di obesità.
 
 
 
#RAPORTO TRA CONSUMO ALCOOL ELL'OBESITA
 plot_distribution(Obesity, "Consumo_Alcool")
 
 #vasializioamo la distribuzione di categorie di peso per il consumo di Alcool 
 cross_tab2 <- table(Obesity$Categorie_Peso, Obesity$Consumo_Alcool)
 ggplot(data = as.data.frame.table(cross_tab2), aes(Var2, Var1, fill = Freq)) +
   geom_tile(color = "white") +
   scale_fill_gradient(low = "#F2F3F4", high = "pink") +  
   geom_text(aes(label = Freq), color = "black", size = 4) +
   labs(title = "Consumo di Alcool per Categorie di peso", x = "", y = "") +
   theme_minimal() +
   theme(axis.text.x = element_text(angle = 45, hjust = 1))
 
   #Non ci sono persone con obesità o sovrappeso che bevono alcolici sempre, e si osserva che pochi con obesità bevono frequentemente. 
   #Sembra quindi che il consumo di alcool non sia associato a un rischio di obesità.
 
#RAPPORTO TRA TRASPORTO UTTILIZATO ELL'OBESITA
 plot_distribution(Obesity, "Trasporto_Utilizzato")

#osserviamo la distribuzione di categorie di peso per il mezzo di Trasporto utilizzato
 Obesity_proporzione_9  <- Obesity %>%
   group_by(Categorie_Peso, Trasporto_Utilizzato) %>%
   summarise(
     count = n()
   )
 ggplot(Obesity_proporzione_9, aes(x = Categorie_Peso, y = count , fill = Trasporto_Utilizzato)) +
   geom_bar(stat = "identity", position = "dodge") +
   xlab("Categorie di peso") +
   ylab("Count") +
   ggtitle("Mezzo di Trasporto utilizzato per categorie di peso") +
   scale_fill_manual(values = c("#4caba4", "#d68c78", '#a3a2a2', '#ab90a0', '#e6daa3', '#6782a8', '#8ea677' ))+
   theme_minimal() +
   theme(plot.title = element_text(hjust = 0.5),
         axis.text.x = element_text(angle = 45, hjust = 1))
   #Osserviamo che la maggior parte delle persone utilizza il trasporto pubblico, soprattutto coloro con obesità grave. 
   #Il fatto di utilizzare sempre il trasporto pubblico potrebbe essere associato a un rischio di obesità.